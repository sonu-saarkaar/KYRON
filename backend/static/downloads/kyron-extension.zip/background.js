/*
    ============================================
    KYRON Chrome Extension - Background Service Worker
    ============================================
    
    This file handles:
    - Token synchronization from website localStorage
    - Message passing between components
    - Background tasks
*/

console.log('[KYRON Background] Service worker initialized');

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getToken') {
        // Get token from extension storage
        chrome.storage.local.get(['kyron_token'], function(result) {
            sendResponse({ token: result.kyron_token || null });
        });
        return true; // Required for async response
    } else if (request.action === 'setToken') {
        // Store token in extension storage
        chrome.storage.local.set({ kyron_token: request.token }, function() {
            sendResponse({ success: true });
        });
        return true;
    } else if (request.action === 'clearToken') {
        // Remove token from extension storage
        chrome.storage.local.remove(['kyron_token'], function() {
            sendResponse({ success: true });
        });
        return true;
    }
});

// Sync token from website localStorage when user visits KYRON website
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        // Check if this is the KYRON website (localhost or 127.0.0.1)
        if (tab.url.includes('127.0.0.1') || tab.url.includes('localhost')) {
            chrome.scripting.executeScript({
                target: { tabId: tabId },
                func: () => {
                    try {
                        // Try to read token from localStorage
                        return localStorage.getItem('kyron_token');
                    } catch (e) {
                        return null;
                    }
                }
            }, (results) => {
                if (results && results[0] && results[0].result) {
                    // Store token in extension storage
                    chrome.storage.local.set({ kyron_token: results[0].result });
                    console.log('[KYRON Background] Token synced from website');
                }
            });
        }
    }
});
