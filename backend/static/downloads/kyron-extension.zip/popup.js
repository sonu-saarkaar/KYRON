/*
    ============================================
    KYRON Chrome Extension - Popup Script
    ============================================
    
    This file handles:
    - Popup UI interactions
    - Communicating with content script
    - Status updates
*/

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    
    const statusDiv = document.getElementById('status');
    const activateBtn = document.getElementById('activateBtn');
    const autofillBtn = document.getElementById('autofillBtn');
    const stopBtn = document.getElementById('stopBtn');
    
    // Check current status
    updateStatus();
    
    // Activate agent button
    activateBtn.addEventListener('click', async function() {
        await activateAgent();
    });
    
    // Auto-fill form button
    autofillBtn.addEventListener('click', async function() {
        await triggerAutofill();
    });
    
    // Stop agent button
    stopBtn.addEventListener('click', async function() {
        await stopAgent();
    });
    
    // Update status display
    async function updateStatus() {
        // Get token to check if we can activate
        chrome.storage.local.get(['kyron_token'], function(result) {
            if (result.kyron_token) {
                statusDiv.textContent = 'Ready';
                statusDiv.className = 'status-value inactive';
            } else {
                statusDiv.textContent = 'No Token';
                statusDiv.className = 'status-value inactive';
            }
        });
    }
    
    // Activate agent
    async function activateAgent() {
        activateBtn.disabled = true;
        activateBtn.textContent = 'Activating...';
        
        try {
            // Get current active tab
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            // Send message to content script
            chrome.tabs.sendMessage(tab.id, { 
                action: 'activateFromPopup' 
            }, function(response) {
                if (chrome.runtime.lastError) {
                    console.error(chrome.runtime.lastError);
                    activateBtn.disabled = false;
                    activateBtn.textContent = 'Activate Agent';
                    alert('Error: Please refresh the page and try again.');
                    return;
                }
                
                if (response && response.success) {
                    statusDiv.textContent = 'Active';
                    statusDiv.className = 'status-value active';
                    activateBtn.disabled = true;
                    activateBtn.textContent = 'Activated';
                    autofillBtn.disabled = false;
                    stopBtn.disabled = false;
                } else {
                    activateBtn.disabled = false;
                    activateBtn.textContent = 'Activate Agent';
                    alert(response?.error || 'Failed to activate agent');
                }
            });
        } catch (error) {
            console.error('Error:', error);
            activateBtn.disabled = false;
            activateBtn.textContent = 'Activate Agent';
            alert('Error activating agent');
        }
    }
    
    // Trigger auto-fill
    async function triggerAutofill() {
        autofillBtn.disabled = true;
        autofillBtn.textContent = 'Filling...';
        
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            chrome.tabs.sendMessage(tab.id, { 
                action: 'autofillFromPopup' 
            }, function(response) {
                autofillBtn.disabled = false;
                autofillBtn.textContent = 'Auto Fill Form';
                
                if (chrome.runtime.lastError) {
                    alert('Error: Please refresh the page and try again.');
                    return;
                }
                
                if (response && response.success) {
                    alert(`Successfully filled ${response.filledCount || 0} fields!`);
                } else {
                    alert(response?.error || 'Failed to fill form');
                }
            });
        } catch (error) {
            console.error('Error:', error);
            autofillBtn.disabled = false;
            autofillBtn.textContent = 'Auto Fill Form';
            alert('Error filling form');
        }
    }
    
    // Stop agent
    async function stopAgent() {
        stopBtn.disabled = true;
        stopBtn.textContent = 'Stopping...';
        
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            chrome.tabs.sendMessage(tab.id, { 
                action: 'stopFromPopup' 
            }, function(response) {
                statusDiv.textContent = 'Inactive';
                statusDiv.className = 'status-value inactive';
                activateBtn.disabled = false;
                activateBtn.textContent = 'Activate Agent';
                autofillBtn.disabled = true;
                stopBtn.disabled = false;
                stopBtn.textContent = 'Stop Agent';
                
                if (chrome.runtime.lastError) {
                    console.error(chrome.runtime.lastError);
                }
            });
        } catch (error) {
            console.error('Error:', error);
            stopBtn.disabled = false;
            stopBtn.textContent = 'Stop Agent';
        }
    }
});
