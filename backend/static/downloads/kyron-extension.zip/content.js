/*
    ============================================
    KYRON Chrome Extension - Content Script
    ============================================
    
    This file:
    - Injects floating KYRON logo button on all websites
    - Opens control panel when logo is clicked
    - Handles agent activation and form auto-filling
    - Uses Shadow DOM to avoid CSS conflicts
*/

console.log('[KYRON] Content script loaded');

// Agent state management
let agentState = {
    active: false,
    profile: null,
    token: null,
    widgetCreated: false,
    shadowRoot: null
};

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'activateFromPopup') {
        activateAgent(agentState.shadowRoot).then(() => {
            sendResponse({ success: true });
        }).catch((error) => {
            sendResponse({ success: false, error: error.message });
        });
        return true; // Async response
    } else if (request.action === 'autofillFromPopup') {
        autoFillForm(agentState.shadowRoot).then((filledCount) => {
            sendResponse({ success: true, filledCount: filledCount });
        }).catch((error) => {
            sendResponse({ success: false, error: error.message });
        });
        return true; // Async response
    } else if (request.action === 'stopFromPopup') {
        stopAgent(agentState.shadowRoot);
        sendResponse({ success: true });
        return true;
    }
});

// API base URL
const API_BASE = 'http://127.0.0.1:8000/api';

// Initialize on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// Main initialization function
async function init() {
    // Wait for body to exist
    if (!document.body) {
        await waitForBody();
    }
    
    // Load token from localStorage (primary) or chrome.storage (fallback)
    await loadToken();
    
    // Create the floating widget immediately (always visible)
    createKYRONWidget();
}

// Wait for body element to exist
function waitForBody() {
    return new Promise((resolve) => {
        const checkBody = setInterval(() => {
            if (document.body) {
                clearInterval(checkBody);
                resolve();
            }
        }, 50);
    });
}

// Load token from localStorage or chrome.storage
async function loadToken() {
    // First try to get from page's localStorage
    try {
        const token = localStorage.getItem('kyron_token');
        if (token) {
            agentState.token = token;
            console.log('[KYRON] Token loaded from localStorage');
            // Also sync to chrome.storage for background access
            chrome.storage.local.set({ kyron_token: token });
            return;
        }
    } catch (e) {
        console.log('[KYRON] Cannot access page localStorage, trying extension storage');
    }
    
    // Fallback to chrome.storage
    return new Promise((resolve) => {
        chrome.storage.local.get(['kyron_token'], function(result) {
            agentState.token = result.kyron_token || null;
            if (agentState.token) {
                console.log('[KYRON] Token loaded from extension storage');
            } else {
                console.log('[KYRON] No token found');
            }
            resolve();
        });
    });
}

// Create and inject KYRON widget (floating button + panel)
function createKYRONWidget() {
    if (agentState.widgetCreated) return;
    
    console.log('[KYRON] Creating widget...');
    
    // Create container element
    const container = document.createElement('div');
    container.id = 'kyron-widget-container';
    
    // Create Shadow DOM for CSS isolation
    const shadowRoot = container.attachShadow({ mode: 'open' });
    
    // Inject styles into Shadow DOM
    const style = document.createElement('style');
    style.textContent = getWidgetStyles();
    shadowRoot.appendChild(style);
    
    // Create widget HTML
    const widgetHTML = `
        <button id="kyron-logo-btn" class="kyron-logo-button" title="KYRON Agent">
            K
        </button>
        
        <div id="kyron-panel" class="kyron-panel">
            <div class="kyron-panel-header">
                <h3 class="kyron-panel-title">KYRON</h3>
                <button id="kyron-close-btn" class="kyron-close-button" title="Close">×</button>
            </div>
            
            <div id="kyron-status" class="kyron-status inactive">Agent Inactive</div>
            
            <button id="kyron-activate-btn" class="kyron-button kyron-button-primary">
                ▶ Activate Agent
            </button>
            
            <button id="kyron-autofill-btn" class="kyron-button kyron-button-primary" disabled>
                ✍ Auto Fill Form
            </button>
            
            <button id="kyron-stop-btn" class="kyron-button kyron-button-danger" disabled>
                ⏸ Stop Agent
            </button>
            
            <div id="kyron-message"></div>
        </div>
    `;
    
    // Add widget HTML to Shadow DOM
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = widgetHTML;
    while (tempDiv.firstChild) {
        shadowRoot.appendChild(tempDiv.firstChild);
    }
    
    // Add container to page
    document.body.appendChild(container);
    agentState.widgetCreated = true;
    agentState.shadowRoot = shadowRoot;
    
    // Set up event listeners
    setupEventListeners(shadowRoot);
    
    console.log('[KYRON] Widget created successfully');
}

// Set up event listeners for widget interactions
function setupEventListeners(shadowRoot) {
    const logoBtn = shadowRoot.querySelector('#kyron-logo-btn');
    const panel = shadowRoot.querySelector('#kyron-panel');
    const closeBtn = shadowRoot.querySelector('#kyron-close-btn');
    const activateBtn = shadowRoot.querySelector('#kyron-activate-btn');
    const autofillBtn = shadowRoot.querySelector('#kyron-autofill-btn');
    const stopBtn = shadowRoot.querySelector('#kyron-stop-btn');
    
    // Toggle panel on logo click
    logoBtn.addEventListener('click', () => {
        panel.classList.toggle('visible');
    });
    
    // Close panel
    closeBtn.addEventListener('click', () => {
        panel.classList.remove('visible');
    });
    
    // Activate agent
    activateBtn.addEventListener('click', async () => {
        await activateAgent(shadowRoot);
    });
    
    // Auto-fill form
    autofillBtn.addEventListener('click', async () => {
        await autoFillForm(shadowRoot);
    });
    
    // Stop agent
    stopBtn.addEventListener('click', async () => {
        await stopAgent(shadowRoot);
    });
}

// Activate agent (fetch profile data)
async function activateAgent(shadowRoot) {
    if (!agentState.token) {
        showMessage(shadowRoot, 'Token not found. Please log in to KYRON website first.', 'error');
        return;
    }
    
    const statusDiv = shadowRoot.querySelector('#kyron-status');
    const activateBtn = shadowRoot.querySelector('#kyron-activate-btn');
    const autofillBtn = shadowRoot.querySelector('#kyron-autofill-btn');
    const stopBtn = shadowRoot.querySelector('#kyron-stop-btn');
    
    // Show loading state
    activateBtn.disabled = true;
    activateBtn.textContent = 'Loading...';
    showMessage(shadowRoot, 'Activating agent...', 'info');
    
    try {
        const response = await fetch(`${API_BASE}/profile/me`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${agentState.token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            agentState.profile = data.profile || data; // Handle different response formats
            agentState.active = true;
            
            // Update UI
            statusDiv.textContent = 'Agent Active';
            statusDiv.className = 'kyron-status active';
            activateBtn.disabled = true;
            activateBtn.textContent = '✓ Activated';
            autofillBtn.disabled = false;
            stopBtn.disabled = false;
            
            // Update logo button appearance
            const logoBtn = shadowRoot.querySelector('#kyron-logo-btn');
            logoBtn.classList.add('active');
            
            showMessage(shadowRoot, 'Agent activated successfully!', 'success');
            console.log('[KYRON] Agent activated, profile loaded');
        } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
    } catch (error) {
        console.error('[KYRON] Activation error:', error);
        showMessage(shadowRoot, 'Failed to activate agent. Check your connection and token.', 'error');
        
        // Reset UI
        activateBtn.disabled = false;
        activateBtn.textContent = '▶ Activate Agent';
    }
}

// Stop agent
async function stopAgent(shadowRoot) {
    agentState.active = false;
    agentState.profile = null;
    
    const statusDiv = shadowRoot.querySelector('#kyron-status');
    const activateBtn = shadowRoot.querySelector('#kyron-activate-btn');
    const autofillBtn = shadowRoot.querySelector('#kyron-autofill-btn');
    const stopBtn = shadowRoot.querySelector('#kyron-stop-btn');
    const logoBtn = shadowRoot.querySelector('#kyron-logo-btn');
    
    // Update UI
    statusDiv.textContent = 'Agent Inactive';
    statusDiv.className = 'kyron-status inactive';
    activateBtn.disabled = false;
    activateBtn.textContent = '▶ Activate Agent';
    autofillBtn.disabled = true;
    stopBtn.disabled = true;
    logoBtn.classList.remove('active');
    
    showMessage(shadowRoot, 'Agent stopped', 'info');
    console.log('[KYRON] Agent stopped');
}

// Auto-fill form with profile data
async function autoFillForm(shadowRoot) {
    console.log('[KYRON] Starting auto-fill...');
    
    if (!agentState.active || !agentState.profile) {
        const message = 'Agent not activated. Please activate first.';
        if (shadowRoot) {
            showMessage(shadowRoot, message, 'error');
        }
        throw new Error(message);
    }
    
    const autofillBtn = shadowRoot.querySelector('#kyron-autofill-btn');
    autofillBtn.disabled = true;
    autofillBtn.textContent = 'Filling...';
    
    // Find all form fields
    const formFields = document.querySelectorAll('input, select, textarea');
    console.log(`[KYRON] Form fields detected: ${formFields.length}`);
    
    let filledCount = 0;
    
    formFields.forEach(field => {
        // Skip fields that should not be filled
        if (shouldSkipField(field)) {
            return;
        }
        
        // Match field with profile data
        const value = matchField(field);
        if (value) {
            // Fill the field
            if (field.tagName === 'SELECT') {
                // For select dropdowns, try to find matching option
                const options = field.options;
                for (let i = 0; i < options.length; i++) {
                    if (options[i].text.toLowerCase().includes(value.toLowerCase()) || 
                        options[i].value.toLowerCase() === value.toLowerCase()) {
                        field.selectedIndex = i;
                        break;
                    }
                }
            } else {
                field.value = value;
            }
            
            // Highlight filled field with green border
            field.style.border = '2px solid #28a745';
            filledCount++;
            
            // Trigger input and change events so website knows field was filled
            field.dispatchEvent(new Event('input', { bubbles: true }));
            field.dispatchEvent(new Event('change', { bubbles: true }));
        }
    });
    
    // Reset button
    autofillBtn.disabled = false;
    autofillBtn.textContent = '✍ Auto Fill Form';
    
    console.log(`[KYRON] Autofill completed: ${filledCount} fields filled`);
    if (shadowRoot) {
        showMessage(shadowRoot, `Successfully filled ${filledCount} field${filledCount !== 1 ? 's' : ''}!`, 'success');
    }
    return filledCount;
}

// Check if field should be skipped (passwords, CAPTCHA, OTP, etc.)
function shouldSkipField(field) {
    const type = field.type ? field.type.toLowerCase() : '';
    const name = (field.name || '').toLowerCase();
    const id = (field.id || '').toLowerCase();
    const className = (field.className || '').toLowerCase();
    const placeholder = (field.placeholder || '').toLowerCase();
    
    // Skip password fields
    if (type === 'password') return true;
    
    // Skip hidden fields
    if (type === 'hidden') return true;
    
    // Skip disabled or readonly fields
    if (field.disabled || field.readOnly) return true;
    
    // Skip CAPTCHA fields
    if (name.includes('captcha') || id.includes('captcha') || 
        className.includes('captcha') || placeholder.includes('captcha')) {
        return true;
    }
    
    // Skip OTP/PIN fields
    if (name.includes('otp') || id.includes('otp') || 
        name.includes('pin') || id.includes('pin') ||
        name.includes('verification') || id.includes('verification')) {
        return true;
    }
    
    return false;
}

// Match field with profile data based on field labels and attributes
function matchField(field) {
    if (!agentState.profile) return null;
    
    const profile = agentState.profile;
    const name = (field.name || '').toLowerCase();
    const id = (field.id || '').toLowerCase();
    const placeholder = (field.placeholder || '').toLowerCase();
    const label = getFieldLabel(field).toLowerCase();
    
    // Combine all identifiers for matching
    const allText = `${name} ${id} ${label} ${placeholder}`;
    
    // Match name fields
    if (matches(allText, ['name', 'fullname', 'full_name', 'applicant_name', 'person_name', 'full name'])) {
        return profile.fullName || profile.name || null;
    }
    
    // Match father name
    if (matches(allText, ['father', 'father_name', 'fathername', 'father name', 'father\'s name'])) {
        return profile.fatherName || profile.father_name || null;
    }
    
    // Match mother name
    if (matches(allText, ['mother', 'mother_name', 'mothername', 'mother name', 'mother\'s name'])) {
        return profile.motherName || profile.mother_name || null;
    }
    
    // Match date of birth
    if (matches(allText, ['dob', 'dateofbirth', 'date_of_birth', 'birthdate', 'birth date', 'date of birth'])) {
        return profile.dateOfBirth || profile.dob || profile.date_of_birth || null;
    }
    
    // Match gender
    if (matches(allText, ['gender', 'sex'])) {
        return profile.gender || null;
    }
    
    // Match email
    if (matches(allText, ['email', 'e-mail', 'mail', 'email address', 'e-mail address'])) {
        return profile.email || null;
    }
    
    // Match phone/mobile
    if (matches(allText, ['phone', 'mobile', 'telephone', 'contact', 'phone number', 'mobile number', 'contact number'])) {
        return profile.phone || profile.mobile || profile.phoneNumber || null;
    }
    
    // Match address
    if (matches(allText, ['address', 'addr', 'residence', 'residential address', 'permanent address'])) {
        return profile.address || profile.permanentAddress || null;
    }
    
    // Match city
    if (matches(allText, ['city'])) {
        return profile.city || null;
    }
    
    // Match state
    if (matches(allText, ['state'])) {
        return profile.state || null;
    }
    
    // Match pincode
    if (matches(allText, ['pincode', 'pin', 'pin_code', 'zip', 'zipcode', 'postal code'])) {
        return profile.pincode || profile.pinCode || profile.zipCode || null;
    }
    
    // Match Aadhar
    if (matches(allText, ['aadhar', 'aadhaar', 'aadhaar number', 'uid', 'uidai'])) {
        return profile.aadhar || profile.aadhaar || profile.aadhaarNumber || null;
    }
    
    // Match PAN
    if (matches(allText, ['pan', 'pan card', 'pan number', 'pan no'])) {
        return profile.pan || profile.panNumber || profile.panCard || null;
    }
    
    return null;
}

// Helper: Check if any search terms match the text
function matches(text, searchTerms) {
    return searchTerms.some(term => text.includes(term));
}

// Get label text for a form field
function getFieldLabel(field) {
    // Try to find label by 'for' attribute
    if (field.id) {
        const label = document.querySelector(`label[for="${field.id}"]`);
        if (label) {
            return label.textContent.trim() || '';
        }
    }
    
    // Try to find parent label element
    const parentLabel = field.closest('label');
    if (parentLabel) {
        return parentLabel.textContent.trim() || '';
    }
    
    // Try to find preceding label element
    let prev = field.previousElementSibling;
    if (prev && prev.tagName === 'LABEL') {
        return prev.textContent.trim() || '';
    }
    
    // Try to find label in parent container
    const parent = field.parentElement;
    if (parent) {
        const labelInParent = parent.querySelector('label');
        if (labelInParent) {
            return labelInParent.textContent.trim() || '';
        }
    }
    
    return '';
}

// Show message to user
function showMessage(shadowRoot, text, type = 'info') {
    const messageDiv = shadowRoot.querySelector('#kyron-message');
    if (!messageDiv) return;
    
    messageDiv.textContent = text;
    messageDiv.className = `kyron-message ${type} visible`;
    
    // Auto-hide message after 5 seconds
    setTimeout(() => {
        messageDiv.classList.remove('visible');
    }, 5000);
}

// Get widget styles (embedded in Shadow DOM)
function getWidgetStyles() {
    return `
        .kyron-logo-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 999999;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            font-weight: bold;
            transition: transform 0.2s;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .kyron-logo-button:hover {
            transform: scale(1.1);
        }
        
        .kyron-logo-button.active {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        }
        
        .kyron-panel {
            position: fixed;
            bottom: 90px;
            right: 20px;
            width: 280px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            z-index: 999998;
            padding: 20px;
            display: none;
            flex-direction: column;
            gap: 12px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .kyron-panel.visible {
            display: flex;
        }
        
        .kyron-panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .kyron-panel-title {
            font-size: 18px;
            font-weight: bold;
            color: #667eea;
            margin: 0;
        }
        
        .kyron-close-button {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            line-height: 1;
        }
        
        .kyron-close-button:hover {
            color: #333;
        }
        
        .kyron-status {
            font-size: 14px;
            padding: 8px 12px;
            border-radius: 6px;
            text-align: center;
            font-weight: 500;
        }
        
        .kyron-status.active {
            background: #d4edda;
            color: #155724;
        }
        
        .kyron-status.inactive {
            background: #f8d7da;
            color: #721c24;
        }
        
        .kyron-button {
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            width: 100%;
        }
        
        .kyron-button-primary {
            background: #667eea;
            color: white;
        }
        
        .kyron-button-primary:hover:not(:disabled) {
            background: #5568d3;
        }
        
        .kyron-button-danger {
            background: #dc3545;
            color: white;
        }
        
        .kyron-button-danger:hover:not(:disabled) {
            background: #c82333;
        }
        
        .kyron-button:disabled {
            background: #ccc;
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .kyron-message {
            padding: 10px;
            border-radius: 6px;
            font-size: 13px;
            margin-top: 10px;
            display: none;
        }
        
        .kyron-message.visible {
            display: block;
        }
        
        .kyron-message.error {
            background: #f8d7da;
            color: #721c24;
        }
        
        .kyron-message.success {
            background: #d4edda;
            color: #155724;
        }
        
        .kyron-message.info {
            background: #d1ecf1;
            color: #0c5460;
        }
    `;
}
